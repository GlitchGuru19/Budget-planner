this is a simple budget planner made using C++ console that helps calcuate your budget and shows you how much you'll use and what you'll remain with
